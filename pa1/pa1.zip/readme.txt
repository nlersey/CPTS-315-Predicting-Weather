PA1 CPTS 315 
Summer 2022
Libraries used: apyori, pandas

Program instructions: 
Compile pa1.py using python and program will output a ouput.txt file with the top 5 rules for doubles and triples

Developed on Windows OS using VSCODE